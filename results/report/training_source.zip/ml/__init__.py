"""Offline scientific pipeline; never train in HTTP requests."""
