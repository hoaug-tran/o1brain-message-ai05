"""Preregistered English development comparison, never a hidden/final test."""

import argparse
import json
import subprocess
import sys
import time
import zipfile
from datetime import UTC, datetime
from pathlib import Path

import joblib
import numpy as np
from matplotlib import pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.svm import LinearSVC

from ml.common import environment, sha256, source_hash, write_json
from ml.datasets import DATASET_ID, SPLIT_ID, load_btc, prepare, split_btc
from ml.metrics import evaluate

plt.switch_backend("Agg")


def candidates() -> dict:
    return {
        "english_logreg": make_pipeline(
            TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True),
            LogisticRegression(C=4, max_iter=2000, random_state=2026),
        ),
        "english_char_svm": make_pipeline(
            TfidfVectorizer(analyzer="char", ngram_range=(3, 5), sublinear_tf=True),
            LinearSVC(C=1, random_state=2026),
        ),
    }


def select_on_train(
    texts: list[str], labels: list[str], models: dict, folds: int = 5
) -> tuple[str, dict]:
    splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=2026)
    reports = {
        name: evaluate(
            labels,
            cross_val_predict(model, texts, labels, cv=splitter, n_jobs=1).tolist(),
        )
        for name, model in models.items()
    }
    selected = max(
        sorted(reports),
        key=lambda name: (
            reports[name]["metrics"]["spam_f1"] or 0,
            -(reports[name]["metrics"]["ham_fpr"] or 0),
        ),
    )
    return selected, reports


def run(root: Path, dataset: Path) -> None:
    quality = prepare(root, dataset)
    frame, _ = load_btc(dataset)
    train, validation = split_btc(frame)
    split_hash = sha256(root / "data/manifests/english_split.json")
    code_hash = source_hash(root)
    config_path = root / "ml/experiment_plan.json"
    config = json.loads(config_path.read_text())
    run_id = f"en_{sha256(dataset)[:8]}_{split_hash[:8]}_2026_{code_hash[:12]}"
    result_dir = root / "results/experiments" / run_id
    if result_dir.exists():
        raise ValueError(
            "Run already exists; evidence is immutable. Use recorded results."
        )
    result_dir.mkdir(parents=True)
    with zipfile.ZipFile(
        result_dir / "training_source.zip", "w", zipfile.ZIP_DEFLATED
    ) as snapshot:
        for folder in ("src", "ml", "scripts", "tests", "vendor/btc/AI05"):
            for path in sorted((root / folder).rglob("*.py")):
                snapshot.write(path, path.relative_to(root).as_posix())
        for name in ("pyproject.toml", "uv.lock", "ml/experiment_plan.json"):
            snapshot.write(root / name, name)
    write_json(result_dir / "environment.json", environment())
    write_json(result_dir / "config.json", config)
    candidate_models = candidates()
    selected, cv_reports = select_on_train(
        train.text.tolist(), train.label.tolist(), candidate_models
    )
    write_json(
        result_dir / "train_cv.json",
        {
            "folds": 5,
            "seed": 2026,
            "train_ids": train.source_id.tolist(),
            "reports": cv_reports,
            "selected_model_id": selected,
            "uses_outer_validation_labels": False,
        },
        immutable=True,
    )
    write_json(
        result_dir / "model_selection.json",
        {
            "selected_model_id": selected,
            "source_sha256": code_hash,
            "split_sha256": split_hash,
            "config_sha256": sha256(config_path),
            "criterion": "train_only_stratified_5fold_oof_spam_f1_then_ham_fpr",
            "final_test_evaluated": False,
        },
        immutable=True,
    )
    subprocess.run(
        [
            sys.executable,
            "scripts/reproduce_baseline.py",
            "--data",
            str(dataset),
            "--out",
            str(result_dir / "btc"),
        ],
        cwd=root,
        check=True,
    )
    models = {
        "english_baseline": joblib.load(result_dir / "btc/model.joblib"),
        **candidate_models,
    }
    reports: dict[str, dict] = {}
    all_predictions: dict[str, list[str]] = {}
    for model_id, model in models.items():
        started = time.perf_counter()
        if model_id != "english_baseline":
            model.fit(train.text, train.label)
        training_ms = (
            (time.perf_counter() - started) * 1000
            if model_id != "english_baseline"
            else None
        )
        predictions = list(model.predict(validation.text))
        all_predictions[model_id] = predictions
        report: dict = dict(evaluate(list(validation.label), predictions))
        if model_id == "english_baseline":
            official = json.loads(
                (result_dir / "btc/metrics.json").read_text(encoding="utf-8")
            )
            for our_key, their_key in (
                ("spam_f1", "spam_f1"),
                ("spam_precision", "spam_precision"),
                ("spam_recall", "spam_recall"),
                ("ham_fpr", "ham_false_positive_rate"),
            ):
                if report["metrics"][our_key] != official[their_key]:
                    raise ValueError("BTC split/metric parity failed")
        artifact_dir = root / "artifacts" / model_id / run_id
        artifact_dir.mkdir(parents=True)
        artifact = artifact_dir / "model.joblib"
        joblib.dump(model, artifact)
        times = []
        for i in range(100):
            started = time.perf_counter()
            model.predict([str(validation.iloc[i % len(validation)].text)])
            times.append((time.perf_counter() - started) * 1000)
        report.update(
            {
                "experiment_id": run_id,
                "model_id": model_id,
                "dataset_id": DATASET_ID,
                "dataset_sha256": sha256(dataset),
                "split_id": SPLIT_ID,
                "split_manifest_sha256": split_hash,
                "evaluation_scope": "development_validation; model selected on train-only 5-fold OOF; previously inspected outer validation, not pristine final test",
                "baseline_kind": "btc_parser_corrected"
                if model_id == "english_baseline"
                else None,
                "source_sha256": code_hash,
                "config_sha256": sha256(config_path),
                "seed": 2026,
                "training_ms": training_ms,
                "artifact_bytes": artifact.stat().st_size,
                "artifact_sha256": sha256(artifact),
                "latency_ms": {
                    "p50": float(np.percentile(times, 50)),
                    "p95": float(np.percentile(times, 95)),
                    "p99": float(np.percentile(times, 99)),
                },
                "latency_protocol": "100 warm single-message predictions, validation order; CPU",
                "created_at_utc": datetime.now(UTC).isoformat(),
            }
        )
        write_json(result_dir / f"{model_id}.json", report)
        write_json(
            result_dir / f"{model_id}_predictions.json",
            {
                "split_sha256": split_hash,
                "rows": [
                    {
                        "source_id": str(identity),
                        "truth": str(truth),
                        "prediction": predicted,
                    }
                    for identity, truth, predicted in zip(
                        validation.source_id, validation.label, predictions, strict=True
                    )
                ],
            },
        )

        metadata = {
            "model_id": model_id,
            "version": run_id,
            "labels": ["ham", "spam"],
            "language": "en",
            "task": "sms_spam_binary",
            "score_kind": "decision_margin"
            if model_id == "english_char_svm"
            else "uncalibrated_score",
            "threshold": 0 if model_id == "english_char_svm" else 0.5,
            "artifact_sha256": sha256(artifact),
            "dataset_sha256": sha256(dataset),
            "split_sha256": split_hash,
            "source_sha256": code_hash,
            "config_sha256": sha256(config_path),
            "environment": environment(),
            "seed": 2026,
            "test_protocol_status": "development_validation_only",
            "baseline_kind": report["baseline_kind"],
            "preprocessing": model[0].get_params(),
            "licensing": "Public UCI academic research; see README.md and source notices",
        }

        metadata["preprocessing"] = {
            key: value
            if isinstance(value, (str, int, float, bool, type(None), list, tuple))
            else str(value)
            for key, value in metadata["preprocessing"].items()
        }
        write_json(artifact_dir / "metadata.json", metadata)
        write_json(artifact_dir / "validation_metrics.json", report)
        write_json(
            artifact_dir / "train_manifest.json",
            {
                "train_ids": list(train.source_id),
                "validation_ids": list(validation.source_id),
                "split_sha256": split_hash,
            },
        )
        reports[model_id] = report
    paired = paired_bootstrap(
        list(validation.label),
        all_predictions["english_baseline"],
        all_predictions[selected],
    )
    comparison = {
        "run_id": run_id,
        "dataset_id": DATASET_ID,
        "split_id": SPLIT_ID,
        "selected_model_id": selected,
        "selection_rule": config["selection_rule"],
        "train_cv_sha256": sha256(result_dir / "train_cv.json"),
        "final_test_evaluated": False,
        "reports": reports,
        "paired_f1_delta_bootstrap": paired,
    }
    write_json(result_dir / "comparison.json", comparison)
    registry = {
        "active_model_id": selected,
        "run_id": run_id,
        "models": {
            model_id: {
                "artifact": f"{model_id}/{run_id}/model.joblib",
                "metadata": f"{model_id}/{run_id}/metadata.json",
                "artifact_sha256": report["artifact_sha256"],
                "metadata_sha256": sha256(
                    root / "artifacts" / model_id / run_id / "metadata.json"
                ),
            }
            for model_id, report in reports.items()
        },
        "comparison": str(
            (result_dir / "comparison.json").relative_to(root).as_posix()
        ),
        "comparison_sha256": sha256(result_dir / "comparison.json"),
    }
    write_json(root / "artifacts/registry.json", registry)
    generate_figures(root, quality, reports)
    print(
        json.dumps(
            {
                "run_id": run_id,
                "selected": selected,
                "metrics": {key: value["metrics"] for key, value in reports.items()},
                "paired": paired,
            },
            indent=2,
        )
    )


def paired_bootstrap(
    truth: list[str], baseline: list[str], candidate: list[str]
) -> dict[str, object]:
    rng = np.random.default_rng(2026)
    deltas = []
    for _ in range(1000):
        indices = rng.integers(0, len(truth), len(truth))
        actual = [truth[i] for i in indices]
        base = evaluate(actual, [baseline[i] for i in indices])["metrics"]["spam_f1"]
        improved = evaluate(actual, [candidate[i] for i in indices])["metrics"][
            "spam_f1"
        ]
        if base is not None and improved is not None:
            deltas.append(improved - base)
    return {
        "method": "paired percentile bootstrap F1 delta, seed 2026, 1000 resamples",
        "lower_95": float(np.percentile(deltas, 2.5)),
        "upper_95": float(np.percentile(deltas, 97.5)),
        "limitation": "exploratory on reused development validation; not selection-adjusted",
    }


def generate_figures(root: Path, quality: dict, reports: dict[str, dict]) -> None:
    output = root / "results/figures"
    output.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(7, 4))
    counts = quality["class_distribution_clean"]
    ax.bar(list(counts), list(counts.values()))
    ax.set(title=f"UCI English after BTC cleaning ({SPLIT_ID})", ylabel="Messages")
    for i, count in enumerate(counts.values()):
        ax.text(i, count, str(count), ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(output / "class_distribution.png", dpi=130)
    plt.close(fig)
    fig, axes = plt.subplots(1, len(reports), figsize=(12, 4))
    for ax, (name, report) in zip(axes, reports.items(), strict=True):
        c = report["confusion"]
        matrix = [[c["tn"], c["fp"]], [c["fn"], c["tp"]]]
        ax.imshow(matrix, cmap="Blues")
        for i in range(2):
            for j in range(2):
                ax.text(j, i, str(matrix[i][j]), ha="center", va="center")
        ax.set(
            xticks=[0, 1],
            xticklabels=["ham", "spam"],
            yticks=[0, 1],
            yticklabels=["ham", "spam"],
            xlabel="Predicted",
            ylabel="Actual",
            title=name,
        )
    fig.suptitle(f"English development validation — {SPLIT_ID}")
    fig.tight_layout()
    fig.savefig(output / "confusion_matrices.png", dpi=130)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data/raw/SMSSpamCollection"))
    args = parser.parse_args()
    run(Path.cwd(), args.data)


if __name__ == "__main__":
    main()
