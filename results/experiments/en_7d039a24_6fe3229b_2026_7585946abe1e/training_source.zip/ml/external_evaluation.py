"""Retrospective external evaluation of frozen UCI-only models; never trains."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

from ai05.infrastructure.models import ModelRegistry
from ml.common import sha256, write_json
from ml.datasets import load_btc, normalize, split_btc
from ml.metrics import evaluate


def clean_extra(
    rows: list[dict[str, str]], excluded: set[str]
) -> tuple[list[str], list[str], dict[str, int]]:
    labels: dict[str, set[str]] = {}
    original: dict[str, str] = {}
    exact_overlap = 0
    for row in rows:
        label = row["LABEL"].strip().lower()
        if label not in {"ham", "spam", "smishing"} or not row["TEXT"].strip():
            raise ValueError("Invalid external dataset row")
        text = row["TEXT"]
        key = normalize(text)
        if key in excluded:
            exact_overlap += 1
            continue
        labels.setdefault(key, set()).add("ham" if label == "ham" else "spam")
        original.setdefault(key, text)
    conflicts = {key for key, values in labels.items() if len(values) > 1}
    keys = sorted(set(labels) - conflicts)
    return (
        [original[k] for k in keys],
        [next(iter(labels[k])) for k in keys],
        {
            "source_rows": len(rows),
            "exact_overlap_rows_removed": exact_overlap,
            "conflicting_groups_quarantined": len(conflicts),
            "clean_unique_before_near_filter": len(keys),
        },
    )


def clean(rows: list[dict[str, str]]) -> tuple[list[str], list[str], int]:
    labels: dict[str, set[str]] = {}
    originals: dict[str, str] = {}
    for row in rows:
        if row["label"] not in {"0", "1"} or not row["message"].strip():
            raise ValueError("Invalid source row")
        key = normalize(row["message"])
        labels.setdefault(key, set()).add(row["label"])
        originals.setdefault(key, row["message"])
    conflicts = {key for key, values in labels.items() if len(values) > 1}
    keys = sorted(set(labels) - conflicts)
    return (
        [originals[key] for key in keys],
        ["ham" if next(iter(labels[key])) == "0" else "spam" for key in keys],
        len(conflicts),
    )


def filter_near(
    texts: list[str],
    labels: list[str],
    reference: list[str],
    vectorizer: TfidfVectorizer,
) -> tuple[list[str], list[str], int]:
    if not texts:
        raise ValueError("No external examples after cleaning")
    candidates = vectorizer.transform(texts)
    known = vectorizer.transform(reference)
    distances = (
        NearestNeighbors(metric="cosine", algorithm="brute")
        .fit(known)
        .kneighbors(candidates, n_neighbors=1)[0][:, 0]
    )
    indices = np.flatnonzero(distances > 0.1)
    return (
        [texts[i] for i in indices],
        [labels[i] for i in indices],
        len(texts) - len(indices),
    )


def evaluate_set(registry: ModelRegistry, texts: list[str], truth: list[str]) -> dict:
    if set(truth) != {"ham", "spam"}:
        raise ValueError("Both classes required for comparison")
    return {
        name: evaluate(truth, model.predict(texts).tolist())
        for name, model in registry.models.items()
    }


def run(output: Path) -> None:
    if output.exists():
        raise ValueError("Preserve executed evaluation; choose a new output")
    registry_path = Path("artifacts/registry.json")
    before = sha256(registry_path)
    registry = ModelRegistry(registry_path)
    if not registry.ready:
        raise ValueError("Verified frozen UCI models required")
    frame, _ = load_btc(Path("data/raw/SMSSpamCollection"))
    train, validation = split_btc(frame)
    manifest = json.loads(Path("data/manifests/english_split.json").read_text())
    if set(train.source_id) != set(manifest["train"]) or set(
        validation.source_id
    ) != set(manifest["validation"]):
        raise ValueError("Frozen split changed")
    for metadata in registry.metadata.values():
        if metadata["dataset_sha256"] != sha256(Path("data/raw/SMSSpamCollection")):
            raise ValueError("Training dataset provenance mismatch")
    sources = {}
    for name, filename in [
        ("english-smishing-source", "PhishNet_Dataset1_original.csv"),
        ("vietnamese-original", "full_dataset.csv"),
    ]:
        source = Path("data/research") / name / filename
        provenance = json.loads((source.parent / "SOURCE.json").read_text())
        if sha256(source) != provenance["source_sha256"]:
            raise ValueError("External source checksum mismatch")
        sources[name] = provenance
    output.mkdir(parents=True)
    plan = {
        "scope": "retrospective_external_evaluation_of_frozen_uci_models",
        "training_dataset": "uci_sms_spam_en_v1",
        "training_dataset_sha256": sha256(Path("data/raw/SMSSpamCollection")),
        "registry_sha256": before,
        "models": {
            name: metadata["artifact_sha256"]
            for name, metadata in registry.metadata.items()
        },
        "thresholds": {
            name: metadata["threshold"] for name, metadata in registry.metadata.items()
        },
        "external_sources": sources,
        "selection_or_tuning": False,
        "history_disclosure": "External sources previously trained discarded research models; user examples and rules have been inspected. These are retrospective comparisons, not pristine blind tests. No external fitting, model selection or threshold changes in this run.",
        "label_mapping": "English: ham=ham; spam/smishing=spam. Vietnamese: 0=ham,1=spam. Not verified fraud labels.",
        "overlap_rule": "normalized exact and char3-5 cosine>=0.9 against all UCI, using existing UCI-trained vectorizer only",
        "script_sha256": sha256(Path(__file__)),
        "app_policy_sha256_before_external_evaluation": sha256(
            Path("android/app/src/main/java/vn/uneti/ai05/ProductDetector.kt")
        ),
    }
    write_json(output / "plan.json", plan, immutable=True)
    vectorizer = registry.models[registry.active].steps[0][1]
    datasets: dict[str, tuple[list[str], list[str], dict]] = {
        "uci_validation": (
            validation.text.tolist(),
            validation.label.tolist(),
            {"scope": "development_validation_used_for_model_selection"},
        )
    }
    with Path(
        "data/research/english-smishing-source/PhishNet_Dataset1_original.csv"
    ).open(encoding="utf-8-sig", newline="") as handle:
        texts, labels, quality = clean_extra(
            list(csv.DictReader(handle)), set(map(normalize, frame.text))
        )
    texts, labels, removed = filter_near(texts, labels, frame.text.tolist(), vectorizer)
    quality["near_uci_rows_removed"] = removed
    datasets["english_external"] = (texts, labels, quality)
    with Path("data/research/vietnamese-original/full_dataset.csv").open(
        encoding="utf-8-sig", newline=""
    ) as handle:
        rows = list(csv.DictReader(handle))
    texts, labels, conflicts = clean(rows)
    known = set(map(normalize, frame.text))
    kept = [
        (t, y) for t, y in zip(texts, labels, strict=True) if normalize(t) not in known
    ]
    exact = len(texts) - len(kept)
    texts, labels, removed = filter_near(
        [p[0] for p in kept], [p[1] for p in kept], frame.text.tolist(), vectorizer
    )
    datasets["vietnamese_external"] = (
        texts,
        labels,
        {
            "source_rows": len(rows),
            "conflicting_groups_quarantined": conflicts,
            "exact_uci_rows_removed": exact,
            "near_uci_rows_removed": removed,
            "scope": "out_of_training_language; binary model diagnostic only, not app support",
        },
    )
    report: dict = {
        "plan_sha256": sha256(output / "plan.json"),
        "selected_model": registry.active,
        "datasets": {},
    }
    for name, (texts, truth, quality) in datasets.items():
        report["datasets"][name] = {
            "quality": quality,
            "reports": evaluate_set(registry, texts, truth),
        }
        write_json(
            output / f"{name}_ids.json",
            [hashlib.sha256(normalize(t).encode()).hexdigest() for t in texts],
        )
    if sha256(registry_path) != before:
        raise ValueError("Registry changed during evaluation")
    write_json(output / "comparison.json", report, immutable=True)
    asset = Path("android/app/src/main/assets/external_evidence.json")
    write_json(
        asset,
        {
            "model_sha256": sha256(
                Path("android/app/src/main/assets/english_char_svm.json")
            ),
            "scope": plan["scope"],
            "history_disclosure": plan["history_disclosure"],
            **report,
        },
    )
    asset.parent.parent.joinpath("external_evidence.sha256").write_text(
        sha256(asset) + "\n"
    )
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args().output)
