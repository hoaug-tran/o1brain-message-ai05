from ml.external_evaluation import clean_extra


def test_external_rows_never_include_uci_overlap_or_conflicting_labels() -> None:
    rows = [
        {"LABEL": "ham", "TEXT": "Known UCI text"},
        {"LABEL": "Smishing", "TEXT": "Pay a fake fee now"},
        {"LABEL": "Spam", "TEXT": "pay a FAKE fee now"},
        {"LABEL": "ham", "TEXT": "Conflicting text"},
        {"LABEL": "spam", "TEXT": "conflicting TEXT"},
        {"LABEL": "ham", "TEXT": "New legitimate reminder"},
    ]
    texts, labels, quality = clean_extra(rows, {"known uci text"})
    assert dict(zip(texts, labels, strict=True)) == {
        "New legitimate reminder": "ham",
        "Pay a fake fee now": "spam",
    }
    assert quality["exact_overlap_rows_removed"] == 1
    assert quality["conflicting_groups_quarantined"] == 1
