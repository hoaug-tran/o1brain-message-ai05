import pytest

from ml.external_evaluation import clean


def test_vietnamese_cleaning_quarantines_conflicts_and_keeps_original_text() -> None:
    rows = [
        {"message": "  Xin chào  ", "label": "0"},
        {"message": "xin CHÀO", "label": "0"},
        {"message": "Trúng thưởng", "label": "1"},
        {"message": "trúng thưởng", "label": "0"},
        {"message": "Nhận quà ngay", "label": "1"},
    ]
    texts, labels, conflicts = clean(rows)
    assert conflicts == 1
    assert set(zip(texts, labels, strict=True)) == {
        ("  Xin chào  ", "ham"),
        ("Nhận quà ngay", "spam"),
    }
    with pytest.raises(ValueError):
        clean([{"message": "x", "label": "phishing"}])
