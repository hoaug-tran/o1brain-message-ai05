from sklearn.feature_extraction.text import TfidfVectorizer

from ml.benchmark import candidates, select_on_train


def test_selection_fits_preprocessing_only_inside_train_folds(monkeypatch):
    texts = [f"Hello friend meeting tomorrow library {i}" for i in range(10)] + [
        f"FREE prize WIN cash claim today {i}" for i in range(10)
    ]
    labels = ["ham"] * 10 + ["spam"] * 10
    observed = []
    original = TfidfVectorizer.fit_transform

    def checked(self, raw_documents, *args, **kwargs):
        documents = list(raw_documents)
        assert set(documents) <= set(texts)
        assert len(documents) < len(texts)
        observed.append(len(documents))
        return original(self, documents, *args, **kwargs)

    monkeypatch.setattr(TfidfVectorizer, "fit_transform", checked)
    selected, reports = select_on_train(texts, labels, candidates(), folds=2)
    assert selected in reports and len(reports) == 2
    assert observed == [10, 10, 10, 10]
    assert all(
        report["support"] == {"ham": 10, "spam": 10} for report in reports.values()
    )
