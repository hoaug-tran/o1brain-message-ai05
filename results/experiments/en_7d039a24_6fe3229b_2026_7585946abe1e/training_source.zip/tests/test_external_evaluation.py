from pathlib import Path

import pytest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline

from ai05.infrastructure.models import ModelRegistry
from ml.common import sha256
from ml.external_evaluation import evaluate_set, filter_near


def test_external_comparison_never_fits_and_does_not_change_registry(monkeypatch):
    registry_path = Path("artifacts/registry.json")
    before = sha256(registry_path)
    registry = ModelRegistry(registry_path)

    def forbidden(*args, **kwargs):
        raise AssertionError("External evaluation must never fit")

    monkeypatch.setattr(Pipeline, "fit", forbidden)
    monkeypatch.setattr(TfidfVectorizer, "fit", forbidden)
    monkeypatch.setattr(TfidfVectorizer, "fit_transform", forbidden)
    result = evaluate_set(
        registry,
        ["See you tomorrow.", "FREE entry call now to win a prize!"],
        ["ham", "spam"],
    )
    assert set(result) == set(registry.models)
    assert all(row["support"] == {"ham": 1, "spam": 1} for row in result.values())
    assert sha256(registry_path) == before
    with pytest.raises(ValueError):
        evaluate_set(registry, ["single class"], ["ham"])


def test_near_filter_uses_training_vocabulary_without_refitting(monkeypatch):
    registry = ModelRegistry(Path("artifacts/registry.json"))
    vectorizer = registry.models[registry.active].steps[0][1]

    def forbidden(*args, **kwargs):
        raise AssertionError("Do not learn test vocabulary")

    monkeypatch.setattr(TfidfVectorizer, "fit_transform", forbidden)
    texts, labels, removed = filter_near(
        ["See you tomorrow.", "Unrelated domain identity sequence"],
        ["ham", "spam"],
        ["See you tomorrow."],
        vectorizer,
    )
    assert removed == 1
    assert texts == ["Unrelated domain identity sequence"] and labels == ["spam"]


def test_android_asset_is_exact_export_of_frozen_uci_model():
    import json

    import numpy as np

    root = Path("android/app/src/main/assets")
    assert not list(root.glob("product_*.json"))
    assert not list(Path("results/research").rglob("*.joblib"))
    asset = json.loads((root / "english_char_svm.json").read_text())
    registry = ModelRegistry(Path("artifacts/registry.json"))
    vectorizer, classifier = [
        step[1] for step in registry.models[registry.active].steps
    ]
    assert (
        asset["source_artifact_sha256"]
        == registry.metadata[registry.active]["artifact_sha256"]
    )
    assert asset["labels"] == ["ham", "spam"] and asset["threshold"] == 0
    assert asset["vocabulary"] == vectorizer.get_feature_names_out().tolist()
    np.testing.assert_array_equal(asset["idf"], vectorizer.idf_)
    np.testing.assert_array_equal(asset["weights"], classifier.coef_[0])
