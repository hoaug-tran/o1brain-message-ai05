"""Build an allowlisted source/model package; never include SMS data or secrets."""

import argparse
import json
import shutil
from pathlib import Path

from ml.common import sha256, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("dist/offline-demo"))
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(
            "Output exists; choose a new directory to preserve package evidence"
        )
    assets = Path("android/app/src/main/assets")
    if any(assets.glob("product_*.json")):
        raise ValueError("External-trained assets forbidden in submission")
    portable = json.loads((assets / "english_char_svm.json").read_text())
    registry = json.loads(Path("artifacts/registry.json").read_text())
    active = registry["models"][registry["active_model_id"]]
    if portable["source_artifact_sha256"] != active["artifact_sha256"]:
        raise ValueError("APK model differs from frozen UCI registry")
    if any(Path("results/research").glob("**/*.joblib")):
        raise ValueError("External-trained research weights forbidden in submission")
    args.output.mkdir(parents=True)
    for name in (
        "src",
        "ml",
        "scripts",
        "tests",
        "artifacts",
        "data/manifests",
        "docs",
        "migrations",
        "vendor/btc",
        "results",
        "android",
        "deploy",
        "o1brain",
    ):
        shutil.copytree(
            name,
            args.output / name,
            ignore=shutil.ignore_patterns(
                "__pycache__",
                "*.pyc",
                "demo_messages.csv",
                "desktop.png",
                "mobile.png",
                "build",
                ".gradle",
                ".kotlin",
                "local.properties",
                "*.jks",
                "*.keystore",
                "*.db*",
            ),
        )
    for name in (
        "pyproject.toml",
        "uv.lock",
        ".python-version",
        ".env.example",
        "alembic.ini",
        "README.md",
        "AGENTS.md",
        "requirements.txt",
        ".dockerignore",
        ".gitignore",
        "Đề thi chung kết cuộc thi Olympic AI.docx",
        "Baseline.zip",
    ):
        destination = args.output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(name, destination)
    for directory in (
        "data/research/vietnamese-original",
        "data/research/english-smishing-source",
    ):
        for filename in ("SOURCE_NOTICE.txt", "LICENSE", "SOURCE.json"):
            source = Path(directory) / filename
            if source.exists():
                destination = args.output / source
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
    (args.output / ".task").mkdir()
    (args.output / "run_windows.ps1").write_text(
        "Set-Location $PSScriptRoot\npython -m uv run --offline --no-sync uvicorn ai05.interfaces.http:app --host 127.0.0.1 --port 8000 --no-access-log\n"
    )
    (args.output / "run_linux.sh").write_text(
        '#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\npython3 -m uv run --offline --no-sync uvicorn ai05.interfaces.http:app --host 127.0.0.1 --port 8000 --no-access-log\n'
    )
    files = {
        path.relative_to(args.output).as_posix(): sha256(path)
        for path in sorted(args.output.rglob("*"))
        if path.is_file()
    }
    if any(
        "private/" in name
        or "data/raw/" in name
        or (name.startswith("data/research/") and name.endswith(".csv"))
        or name.endswith((".db", ".jks", ".keystore"))
        for name in files
    ):
        raise RuntimeError("Forbidden package member")
    write_json(args.output / "checksums.json", files)
    archive = shutil.make_archive(str(args.output), "zip", args.output)
    print(f"Package: {archive}; files: {len(files)}; SHA-256: {sha256(Path(archive))}")


if __name__ == "__main__":
    main()
